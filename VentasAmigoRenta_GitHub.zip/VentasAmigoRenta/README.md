# Ventas Amigo Renta — Android v1.4

App de Marketing y Ventas: Disponibles, Marketing, Website, CRM, Citas, Ventas, Post-reserva, Reportes,
Notificaciones, Segmentación y reactivación. Abre la app web del servidor amigorentacliente (/v) con el
mismo nombre y PIN de la App Operativa. Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).

v1.2: 💬 WhatsApp → CRM (WaListener): con el permiso «Acceso a notificaciones», los mensajes del WhatsApp de trabajo (Business si está instalado) entran solos al CRM.
v1.2: 📤 Compartir un disponible (fotos + texto) directo a Instagram, Facebook, TikTok o WhatsApp; fotos a la galería para Zumper/Craigslist.
v1.3: 📎 Anuncios del equipo (enlaces por día/semana/mes) y acceso «solo anuncios y citas».
v1.4: elegir qué WhatsApp entra al CRM (normal, Business o los dos).
