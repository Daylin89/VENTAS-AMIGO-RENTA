# Ventas Amigo Renta — Android v1.1

App de Marketing y Ventas: Disponibles, Marketing, Website, CRM, Citas, Ventas, Post-reserva, Reportes,
Notificaciones, Segmentación y reactivación. Abre la app web del servidor amigorentacliente (/v) con el
mismo nombre y PIN de la App Operativa. Se compila con GitHub Actions (.github/workflows/compilar-apk.yml).
