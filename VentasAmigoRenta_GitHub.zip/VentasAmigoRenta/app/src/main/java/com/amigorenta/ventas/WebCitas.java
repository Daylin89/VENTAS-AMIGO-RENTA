package com.amigorenta.ventas;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Icon;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * 🌐 Citas que un cliente agenda en la página web: cada ~15 minutos (aunque la app esté cerrada) pregunta al servidor
 * si hay citas nuevas y avisa con una notificación verde, con botón para confirmarle por WhatsApp.
 * Usa la sesión de quien entró en la app (la misma que WhatsApp → CRM). Los vendedores con acceso «solo Citas» no reciben estos avisos.
 */
public class WebCitas extends BroadcastReceiver {
    static final String CH = "citasweb";

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("ventas", Context.MODE_PRIVATE); }

    static void start(Context ctx) {
        Context c = ctx.getApplicationContext();
        PendingIntent pi = PendingIntent.getBroadcast(c, 41, new Intent(c, WebCitas.class).setAction("POLL"), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE))
                .setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 60000, AlarmManager.INTERVAL_FIFTEEN_MINUTES, pi);
    }

    @Override
    public void onReceive(Context ctx, Intent i) {
        final Context c = ctx.getApplicationContext();
        String a = i == null ? null : i.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) { start(c); return; }
        final PendingResult pr = goAsync();
        new Thread(() -> { try { poll(c); } finally { pr.finish(); } }).start();
    }

    static volatile boolean busy = false;

    /** Pregunta al servidor por citas web nuevas y avisa. La primera vez solo marca el punto de partida. */
    static void poll(Context c) {
        if (busy) return;
        busy = true;
        try {
            SharedPreferences p = sp(c);
            String tok = p.getString("waTok", ""), srv = p.getString("waSrv", MainActivity.DEF_SERVER);
            if (tok.isEmpty()) return;
            long since = p.getLong("wcSince", 0);
            HttpURLConnection h = (HttpURLConnection) new URL(srv + "/api/o/v/webappts?since=" + (since > 0 ? since : System.currentTimeMillis())).openConnection();
            h.setConnectTimeout(15000);
            h.setReadTimeout(20000);
            h.setRequestProperty("X-O-Token", tok);
            int code = h.getResponseCode();
            if (code != 200) { h.disconnect(); return; }
            InputStream in = h.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            h.disconnect();
            JSONObject j = new JSONObject(new String(bo.toByteArray(), StandardCharsets.UTF_8));
            if (since > 0) {
                JSONArray items = j.optJSONArray("items");
                if (items != null) for (int k = 0; k < items.length(); k++) notify(c, items.getJSONObject(k));
            }
            p.edit().putLong("wcSince", j.optLong("now", System.currentTimeMillis())).apply();
        } catch (Exception ignored) {
        } finally { busy = false; }
    }

    static String nice(String date) {
        try {
            java.time.LocalDate d = java.time.LocalDate.parse(date);
            return d.format(java.time.format.DateTimeFormatter.ofPattern("EEEE d 'de' MMMM", new java.util.Locale("es")));
        } catch (Exception e) { return date; }
    }

    static void notify(Context c, JSONObject d) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch = new NotificationChannel(CH, "Citas desde la página web", NotificationManager.IMPORTANCE_HIGH);
        ch.setLightColor(0xFF16A34A);
        ch.enableLights(true);
        nm.createNotificationChannel(ch);
        String name = d.optString("name"), when = nice(d.optString("date")), time = d.optString("time"), notes = d.optString("notes");
        int id = 50000 + Math.abs(d.optString("id").hashCode() % 40000);
        Intent open = new Intent(c, MainActivity.class).putExtra("open", "appt:" + d.optString("id")).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent po = PendingIntent.getActivity(c, id, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String text = name + " · " + when + " a las " + time + (notes.isEmpty() ? "" : "\n" + notes);
        Notification.Builder b = new Notification.Builder(c, CH)
                .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
                .setColor(0xFF16A34A)
                .setContentTitle("🌐 Nueva cita desde la página web")
                .setContentText(name + " · " + when + " " + time)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(po)
                .setAutoCancel(true);
        String ph = d.optString("phone").replaceAll("[^0-9]", "");
        if (ph.length() == 10) ph = "1" + ph;
        if (ph.length() >= 8) {
            String first = name.trim().split("\\s+")[0];
            String msg = "Hola " + first + " 👋 Recibimos tu cita para el " + when + " a las " + time + ". ¡Te esperamos! ¿Nos confirmas?";
            Intent wa = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + ph + "?text=" + Uri.encode(msg))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            PendingIntent pw = PendingIntent.getActivity(c, id + 1, wa, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            b.addAction(new Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.sym_action_chat), "💬 Confirmar por WhatsApp", pw).build());
        }
        nm.notify(id, b.build());
    }
}
