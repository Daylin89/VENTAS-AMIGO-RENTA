package com.amigorenta.ventas;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Check-in · Amigo Renta.
 * La app abre la app web de check-in / check-out / maquillaje del servidor (amigorentacliente, ruta /c),
 * así todo lo que se guarda lo ve el equipo (Daylin, Manager, trabajadores) al momento.
 * Sin internet abre la copia que trae la app (con los últimos datos guardados en el teléfono).
 */
public class MainActivity extends Activity {
    static final String DEF_SERVER = "https://amigorentacliente.muddy-pine-c15e.workers.dev";
    static final int REQ_FILES = 41, REQ_CAMERA = 42;
    static final int PRI = 0xFF0D3B7A;

    WebView web;
    String pendingOpen = ""; // al tocar una notificación de cita web: qué abrir en la app
    ProgressBar bar;
    ValueCallback<Uri[]> fileCb;
    Uri camUri;
    boolean usingOffline = false;

    SharedPreferences sp() { return getSharedPreferences("ventas", MODE_PRIVATE); }

    String server() {
        String s = sp().getString("server", DEF_SERVER).trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s.isEmpty() ? DEF_SERVER : s;
    }

    String appUrl() { return server() + "/v"; }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setIndeterminate(true);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-1, dp(4));
        bl.gravity = Gravity.TOP;
        root.addView(bar, bl);
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUserAgentString(s.getUserAgentString() + " AmigoOperApp/1.0");
        CookieManager.getInstance().setAcceptCookie(true);
        web.addJavascriptInterface(new Bridge(), "AmigoApp");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());

        // siempre la versión más nueva del servidor (los cambios que hace Claude llegan sin reinstalar)
        web.clearCache(true);
        if (getIntent() != null && getIntent().getStringExtra("open") != null) pendingOpen = getIntent().getStringExtra("open");
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 12);
        if (!sp().getString("waTok", "").isEmpty()) WebCitas.start(this);
        web.loadUrl(appUrl());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    // ---------------------------------------------------------------- navegación
    class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return handleUrl(r.getUrl()); }

        @Override
        public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) { bar.setVisibility(View.VISIBLE); }

        @Override
        public void onPageFinished(WebView v, String url) { bar.setVisibility(View.GONE); if (!pendingOpen.isEmpty()) v.postDelayed(() -> v.evaluateJavascript("window.openFromNotif && openFromNotif()", null), 1800); }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame() && !usingOffline) loadOffline();
        }
    }

    /** true si el enlace se abre fuera de la app (WhatsApp, llamadas, correo, otras páginas). */
    boolean handleUrl(Uri u) {
        if (u == null) return true;
        String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        String host = u.getHost() == null ? "" : u.getHost();
        Uri srv = Uri.parse(server());
        if ((sc.equals("https") || sc.equals("http")) && host.equalsIgnoreCase(srv.getHost())) {
            String path = u.getPath() == null ? "" : u.getPath();
            if (path.equals("/v") || path.startsWith("/v/") || path.startsWith("/api/")) return false;
        }
        if (sc.equals("data") || sc.equals("blob") || sc.equals("about")) return false;
        openExternal(u);
        return true;
    }

    void openExternal(Uri u) {
        String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
        try {
            Intent i;
            if (sc.equals("tel")) i = new Intent(Intent.ACTION_DIAL, u);
            else if (sc.equals("intent")) i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
            else i = new Intent(Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            toast("No hay una app para abrir esto");
        } catch (Exception e) {
            toast("No se pudo abrir: " + e.getMessage());
        }
    }

    /** Sin internet: abre la copia de la app que viene dentro (usa los datos guardados en el teléfono). */
    void loadOffline() {
        usingOffline = true;
        try {
            InputStream in = getAssets().open("vent.html");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            web.loadDataWithBaseURL(appUrl(), new String(bo.toByteArray(), StandardCharsets.UTF_8), "text/html", "UTF-8", appUrl());
            toast("Sin conexión: se abre con los últimos datos guardados");
        } catch (Exception e) {
            web.loadData("<h3 style='font-family:sans-serif;padding:20px'>Sin conexión. Revisa el internet y vuelve a abrir la app.</h3>", "text/html", "UTF-8");
        }
    }

    // ---------------------------------------------------------------- diálogos, ventanas y fotos
    class Chrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) { bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE); }

        @Override
        public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
            new AlertDialog.Builder(MainActivity.this).setMessage(msg).setPositiveButton("OK", (d, w) -> r.confirm())
                    .setOnCancelListener(d -> r.confirm()).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
            new AlertDialog.Builder(MainActivity.this).setMessage(msg)
                    .setPositiveButton("Sí", (d, w) -> r.confirm())
                    .setNegativeButton("No", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        @Override
        public boolean onJsPrompt(WebView v, String url, String msg, String def, JsPromptResult r) {
            EditText e = new EditText(MainActivity.this);
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            if (def != null) { e.setText(def); e.setSelection(def.length()); }
            LinearLayout box = new LinearLayout(MainActivity.this);
            box.setPadding(dp(20), dp(4), dp(20), 0);
            box.addView(e, new LinearLayout.LayoutParams(-1, -2));
            new AlertDialog.Builder(MainActivity.this).setMessage(msg).setView(box)
                    .setPositiveButton("OK", (d, w) -> r.confirm(e.getText().toString()))
                    .setNegativeButton("Cancelar", (d, w) -> r.cancel())
                    .setOnCancelListener(d -> r.cancel()).show();
            return true;
        }

        /** window.open(...) y enlaces con target=_blank: WhatsApp y demás se abren fuera de la app. */
        @Override
        public boolean onCreateWindow(WebView v, boolean dialog, boolean user, Message msg) {
            WebView tmp = new WebView(MainActivity.this);
            final boolean[] done = {false};
            tmp.setWebViewClient(new WebViewClient() {
                void go(WebView w, String url) {
                    if (done[0] || url == null || url.startsWith("about:")) return;
                    done[0] = true;
                    if (!handleUrl(Uri.parse(url))) web.loadUrl(url);
                    w.post(() -> { try { w.stopLoading(); w.destroy(); } catch (Exception e) { } });
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest r) { go(w, r.getUrl().toString()); return true; }

                @Override
                public void onPageStarted(WebView w, String url, android.graphics.Bitmap f) { go(w, url); }
            });
            WebView.WebViewTransport t = (WebView.WebViewTransport) msg.obj;
            t.setWebView(tmp);
            msg.sendToTarget();
            return true;
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            final boolean multi = p.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE;
            boolean vid = false; for (String t : p.getAcceptTypes()) if (t != null && t.startsWith("video")) vid = true;
            if (vid) { // 🎬 video de acceso: grabarlo o elegirlo de la galería
                new AlertDialog.Builder(MainActivity.this).setTitle("Video del acceso")
                        .setItems(new String[]{"🎥 Grabar video ahora", "🎞️ Elegir de la galería"}, (d, w) -> {
                            Intent i = w == 0 ? new Intent(MediaStore.ACTION_VIDEO_CAPTURE) : new Intent(Intent.ACTION_GET_CONTENT);
                            if (w == 1) { i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("video/*"); }
                            try { startActivityForResult(w == 1 ? Intent.createChooser(i, "Elegir video") : i, REQ_FILES); } catch (Exception e) { toast("No se pudo abrir"); finishFiles(null); }
                        })
                        .setOnCancelListener(d -> finishFiles(null)).show();
                return true;
            }
            new AlertDialog.Builder(MainActivity.this).setTitle("Agregar foto")
                    .setItems(new String[]{"📷 Tomar foto", multi ? "🖼️ Elegir de la galería (una o varias)" : "🖼️ Elegir de la galería"}, (d, w) -> {
                        if (w == 0) takePhoto(); else pickImages(multi);
                    })
                    .setOnCancelListener(d -> finishFiles(null)).show();
            return true;
        }
    }

    void finishFiles(Uri[] r) {
        if (fileCb != null) fileCb.onReceiveValue(r);
        fileCb = null;
    }

    void takePhoto() {
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
            toast("Acepta el permiso y vuelve a tocar «Tomar foto»");
            finishFiles(null);
            return;
        }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "ventas_" + System.currentTimeMillis() + ".jpg");
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
        if (Build.VERSION.SDK_INT >= 29) cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Amigo Renta Ventas");
        try { camUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv); } catch (Exception e) { camUri = null; }
        if (camUri == null) { toast("No se pudo preparar la cámara"); finishFiles(null); return; }
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        i.putExtra(MediaStore.EXTRA_OUTPUT, camUri);
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try { startActivityForResult(i, REQ_CAMERA); } catch (Exception e) { toast("No hay app de cámara"); finishFiles(null); }
    }

    void pickImages(boolean multi) {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        if (multi) i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(Intent.createChooser(i, "Elegir fotos"), REQ_FILES); } catch (Exception e) { toast("No se pudo abrir la galería"); finishFiles(null); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAMERA) {
            if (res == RESULT_OK && camUri != null) finishFiles(new Uri[]{camUri});
            else {
                if (camUri != null) try { getContentResolver().delete(camUri, null, null); } catch (Exception e) { }
                finishFiles(null);
            }
            camUri = null;
        } else if (req == REQ_FILES) {
            if (res != RESULT_OK || data == null) { finishFiles(null); return; }
            if (data.getClipData() != null) {
                int n = data.getClipData().getItemCount();
                Uri[] us = new Uri[n];
                for (int k = 0; k < n; k++) us[k] = data.getClipData().getItemAt(k).getUri();
                finishFiles(us);
            } else if (data.getData() != null) finishFiles(new Uri[]{data.getData()});
            else finishFiles(null);
        }
    }

    // ---------------------------------------------------------------- puente con la página
    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i != null && i.getStringExtra("open") != null) { pendingOpen = i.getStringExtra("open"); if (web != null) web.evaluateJavascript("window.openFromNotif && openFromNotif()", null); }
    }

    class Bridge {
        /** Qué abrir al tocar una notificación (ej. "appt:web-123"); se entrega una sola vez. */
        @JavascriptInterface
        public String pendingOpen() { String p = pendingOpen; pendingOpen = ""; return p; }

        @JavascriptInterface
        public void printHtml(String html, String title) { runOnUiThread(() -> printDoc(html, title)); }

        @JavascriptInterface
        public void changeServer() { runOnUiThread(MainActivity.this::askServer); }

        @JavascriptInterface
        public String version() { return "1.7"; }

        /**
         * 📤 Compartir un disponible: fotos + texto. files = JSON [{b64, mime, name}]. pkg = app de destino
         * (Instagram, Facebook, TikTok, WhatsApp) o vacío para elegir. save = solo guardar en la galería.
         * El texto queda copiado: Instagram y Facebook no dejan poner el texto solos, se pega.
         */
        @JavascriptInterface
        public void shareImages(String files, String text, String pkg, boolean save) {
            runOnUiThread(() -> {
                try {
                    org.json.JSONArray a = new org.json.JSONArray(files);
                    java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                    for (int i = 0; i < a.length(); i++) {
                        org.json.JSONObject f = a.getJSONObject(i);
                        Uri u = writeImage(f.getString("b64"), f.optString("mime", "image/jpeg"), f.optString("name", "foto" + i + ".jpg"));
                        if (u != null) uris.add(u);
                    }
                    if (text != null && !text.isEmpty()) {
                        android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("Anuncio", text));
                    }
                    if (save) { toast(uris.size() + " fotos en la galería (Amigo Renta Ventas) · texto copiado"); return; }
                    Intent i;
                    if (uris.isEmpty()) { i = new Intent(Intent.ACTION_SEND); i.setType("text/plain"); }
                    else if (uris.size() == 1) { i = new Intent(Intent.ACTION_SEND); i.setType("image/*"); i.putExtra(Intent.EXTRA_STREAM, uris.get(0)); }
                    else { i = new Intent(Intent.ACTION_SEND_MULTIPLE); i.setType("image/*"); i.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris); }
                    if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if (pkg != null && !pkg.isEmpty()) {
                        String target = pkg.equals("wa") ? waPkg() : has(pkg) ? pkg : null;
                        if (target != null) {
                            Intent t = new Intent(i); t.setPackage(target);
                            try { startActivity(t); toast("El texto está copiado: mantén el dedo y Pegar"); return; } catch (Exception e) { }
                        }
                    }
                    startActivity(Intent.createChooser(i, "Publicar en…"));
                    toast("El texto está copiado: mantén el dedo y Pegar");
                } catch (Exception e) { toast("No se pudo compartir: " + e.getMessage()); }
            });
        }

        /** 💬 WhatsApp → CRM: "on" si el permiso de notificaciones está activo, "off" si no. */
        @JavascriptInterface
        public String waStatus() { return WaListener.enabled(MainActivity.this) ? "on" : "off"; }

        /** Qué cuenta de WhatsApp entra al CRM: "wa" (WhatsApp normal), "w4b" (Business), "both" o "auto". */
        @JavascriptInterface
        public String waGetApp() {
            String s = WaListener.appSel(MainActivity.this);
            return s + "|" + (WaListener.installed(MainActivity.this, WaListener.WA) ? "wa" : "") + "," + (WaListener.installed(MainActivity.this, WaListener.W4B) ? "w4b" : "");
        }

        /** Cuál WhatsApp verde: "main" el principal, "dual" el duplicado (Dual Messenger / Apps gemelas), "both" los dos. */
        @JavascriptInterface
        public String waGetProfile() { return sp().getString("waProfile", "both") + "|" + (sp().getBoolean("waSeenDual", false) ? "seen" : ""); }

        @JavascriptInterface
        public void waSetProfile(String v) {
            if (!"main".equals(v) && !"dual".equals(v)) v = "both";
            sp().edit().putString("waProfile", v).apply();
        }

        @JavascriptInterface
        public void waSetApp(String v) {
            if (!"wa".equals(v) && !"w4b".equals(v) && !"both".equals(v)) v = "auto";
            sp().edit().putString("waApp", v).apply();
        }

        /** Abre el permiso «Acceso a notificaciones» para activar o quitar WhatsApp → CRM. */
        @JavascriptInterface
        public void waEnable() {
            runOnUiThread(() -> {
                try { startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); }
                catch (Exception e) { toast("Abre Ajustes → Notificaciones → Acceso a notificaciones"); }
            });
        }

        /** La sesión de quien entró (para mandar los mensajes al CRM a su nombre). Vacío al salir. */
        @JavascriptInterface
        public void waAuth(String server, String token, String name) {
            String srv = server == null || !server.startsWith("https://") ? server() : server;
            sp().edit().putString("waSrv", srv).putString("waTok", token == null ? "" : token).putString("waName", name == null ? "" : name).apply();
            if (token == null || token.isEmpty()) sp().edit().putString("waq", "[]").putLong("wcSince", 0).apply();
            else { WaListener.flush(MainActivity.this); WebCitas.start(MainActivity.this); new Thread(() -> WebCitas.poll(getApplicationContext())).start(); }
        }

        /** Guarda un archivo (Excel, respaldo, documento) en Descargas → Amigo Renta Ventas. */
        @JavascriptInterface
        public void saveFile(String b64, String mime, String name) {
            runOnUiThread(() -> {
                Uri u = writeDownload(b64, mime, name);
                if (u == null) return;
                new AlertDialog.Builder(MainActivity.this).setTitle("Guardado ✅")
                        .setMessage("Está en Descargas → Amigo Renta Ventas:\n" + name)
                        .setPositiveButton("Abrir", (d, w) -> {
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setDataAndType(u, mime);
                            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                            try { startActivity(i); } catch (Exception e) { toast("No hay una app para abrir este archivo"); }
                        })
                        .setNegativeButton("OK", null).show();
            });
        }

        /** 🎬 Comparte un video del servidor (acceso de una habitación): lo baja a Descargas → Amigo Renta Ventas y abre WhatsApp. */
        @JavascriptInterface
        public void shareVideoUrl(String url, String name, String text, String phone) {
            toast("Preparando el video…");
            new Thread(() -> {
                Uri u = null;
                try {
                    java.net.HttpURLConnection h = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                    h.setConnectTimeout(20000); h.setReadTimeout(120000);
                    String mime = h.getContentType() == null ? "video/mp4" : h.getContentType().split(";")[0];
                    java.io.InputStream in = h.getInputStream();
                    java.io.OutputStream os;
                    if (Build.VERSION.SDK_INT >= 29) {
                        ContentValues cv = new ContentValues();
                        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                        cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Ventas");
                        u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                        os = getContentResolver().openOutputStream(u);
                    } else {
                        java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Amigo Renta Ventas");
                        dir.mkdirs();
                        java.io.File fl = new java.io.File(dir, name);
                        os = new java.io.FileOutputStream(fl);
                        u = Uri.fromFile(fl);
                    }
                    byte[] b = new byte[65536]; int n;
                    while ((n = in.read(b)) > 0) os.write(b, 0, n);
                    os.close(); in.close(); h.disconnect();
                    final Uri fu = u; final String fm = mime;
                    runOnUiThread(() -> {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType(fm);
                        i.putExtra(Intent.EXTRA_STREAM, fu);
                        if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        String wa = waPkg();
                        if (wa != null) { Intent w = new Intent(i); w.setPackage(wa); if (phone != null && !phone.isEmpty()) w.putExtra("jid", phone + "@s.whatsapp.net"); try { startActivity(w); return; } catch (Exception e) { } }
                        try { startActivity(Intent.createChooser(i, "Enviar video")); } catch (Exception e) { toast("No se pudo compartir"); }
                    });
                } catch (Exception e) { runOnUiThread(() -> toast("No se pudo bajar el video: " + e.getMessage())); }
            }).start();
        }

        /** Comparte un archivo: si viene un número, abre directo ese chat de WhatsApp. */
        @JavascriptInterface
        public void shareFile(String b64, String mime, String name, String text, String phone) {
            runOnUiThread(() -> {
                Uri u = writeDownload(b64, mime, name);
                if (u == null) return;
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, u);
                if (text != null && !text.isEmpty()) i.putExtra(Intent.EXTRA_TEXT, text);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                String wa = phone == null || phone.isEmpty() ? null : waPkg();
                if (wa != null) {
                    Intent w = new Intent(i);
                    w.setPackage(wa);
                    w.putExtra("jid", phone + "@s.whatsapp.net");
                    try { startActivity(w); return; } catch (Exception e) { }
                }
                try { startActivity(Intent.createChooser(i, "Enviar " + name)); } catch (Exception e) { toast("No se pudo compartir"); }
            });
        }

        /** Correo con el archivo adjunto y el destinatario ya puesto (Gmail, Outlook…). */
        @JavascriptInterface
        public void emailFile(String b64, String mime, String name, String email, String subject, String text) {
            runOnUiThread(() -> {
                Uri u = writeDownload(b64, mime, name);
                if (u == null) return;
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_STREAM, u);
                if (email != null && !email.isEmpty()) i.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
                if (subject != null) i.putExtra(Intent.EXTRA_SUBJECT, subject);
                if (text != null) i.putExtra(Intent.EXTRA_TEXT, text);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivity(Intent.createChooser(i, "Enviar por correo")); } catch (Exception e) { toast("No hay app de correo"); }
            });
        }
    }

    String waPkg() {
        String pref = sp().getString("waPkg", "");
        String[] order = pref.isEmpty() ? new String[]{"com.whatsapp.w4b", "com.whatsapp"} : new String[]{pref, "com.whatsapp.w4b", "com.whatsapp"};
        for (String p : order) {
            try { getPackageManager().getPackageInfo(p, 0); return p; } catch (Exception e) { }
        }
        return null;
    }

    /** Escribe el archivo en Descargas/Amigo Renta Ventas y devuelve una dirección que otras apps pueden abrir. */
    /** Foto a la galería (Imágenes → Amigo Renta Ventas), para compartir o subir a Zumper/Craigslist. */
    Uri writeImage(String b64, String mime, String name) {
        if (Build.VERSION.SDK_INT < 29) return writeDownload(b64, mime, name);
        try {
            byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            ContentValues cv = new ContentValues();
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Amigo Renta Ventas");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (u == null) throw new Exception("sin espacio");
            java.io.OutputStream os = getContentResolver().openOutputStream(u);
            os.write(data);
            os.close();
            return u;
        } catch (Exception e) {
            toast("No se pudo guardar la foto: " + e.getMessage());
            return null;
        }
    }

    boolean has(String pkg) { try { getPackageManager().getPackageInfo(pkg, 0); return true; } catch (Exception e) { return false; } }

    Uri writeDownload(String b64, String mime, String name) {
        try {
            byte[] data = android.util.Base64.decode(b64, android.util.Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Amigo Renta Ventas");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) throw new Exception("sin espacio");
                java.io.OutputStream os = getContentResolver().openOutputStream(u);
                os.write(data);
                os.close();
                return u;
            }
            if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 9);
                toast("Acepta el permiso y vuelve a intentarlo");
                return null;
            }
            java.io.File dir = new java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Amigo Renta Ventas");
            dir.mkdirs();
            java.io.File f = new java.io.File(dir, name);
            java.io.FileOutputStream fo = new java.io.FileOutputStream(f);
            fo.write(data);
            fo.close();
            android.os.StrictMode.setVmPolicy(new android.os.StrictMode.VmPolicy.Builder().build());
            return Uri.fromFile(f);
        } catch (Exception e) {
            toast("No se pudo guardar: " + e.getMessage());
            return null;
        }
    }

    /** Imprimir o guardar como PDF la hoja del check-in / check-out. */
    void printDoc(String html, String title) {
        WebView pw = new WebView(this);
        pw.getSettings().setJavaScriptEnabled(false);
        pw.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView v, String url) {
                PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                String name = (title == null || title.trim().isEmpty() ? "Check-in" : title.trim()).replaceAll("[\\\\/:*?\"<>|]", " ");
                try {
                    pm.print(name, v.createPrintDocumentAdapter(name), new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.NA_LETTER).build());
                } catch (Exception e) { toast("No se pudo imprimir: " + e.getMessage()); }
            }
        });
        pw.loadDataWithBaseURL(appUrl(), html, "text/html", "UTF-8", null);
        toast("Elige «Guardar como PDF» o una impresora");
    }

    void askServer() {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setText(server());
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(4), dp(20), 0);
        box.addView(e, new LinearLayout.LayoutParams(-1, -2));
        TextView h = new TextView(this);
        h.setText("Es la dirección del servidor amigorentacliente (sin /v al final).");
        h.setTextColor(0xFF6B7585);
        box.addView(h);
        new AlertDialog.Builder(this).setTitle("Dirección del servidor").setView(box)
                .setPositiveButton("Guardar", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (s.endsWith("/v")) s = s.substring(0, s.length() - 2);
                    if (!s.startsWith("http")) s = "https://" + s;
                    sp().edit().putString("server", s).apply();
                    usingOffline = false;
                    web.loadUrl(appUrl());
                })
                .setNeutralButton("Volver a la original", (d, w) -> {
                    sp().edit().remove("server").apply();
                    usingOffline = false;
                    web.loadUrl(appUrl());
                })
                .setNegativeButton("Cancelar", null).show();
    }

    // ---------------------------------------------------------------- botón atrás
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(function(){try{if(typeof S!=='undefined'&&S.view){goBack();return 1}}catch(e){}return 0})()", v -> {
            if (!"1".equals(v)) {
                if (web.canGoBack()) web.goBack();
                else MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
        WaListener.flush(this);
        // al volver de WhatsApp o de la cámara, si estaba sin internet, intenta otra vez
        if (usingOffline) {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            android.net.NetworkInfo ni = cm == null ? null : cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected()) { usingOffline = false; web.loadUrl(appUrl()); }
        }
    }

    @Override
    protected void onPause() {
        web.onPause();
        super.onPause();
    }
}
