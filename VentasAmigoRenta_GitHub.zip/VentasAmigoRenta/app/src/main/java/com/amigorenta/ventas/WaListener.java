package com.amigorenta.ventas;

import android.app.Notification;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * 💬 WhatsApp → CRM: lee las notificaciones del WhatsApp de trabajo de este teléfono y las manda al CRM
 * (servidor /api/o/v/wa con el PIN de quien entró en la app). No guarda nada más que una cola pequeña
 * mientras no hay internet. No lee grupos ni estados.
 */
public class WaListener extends NotificationListenerService {
    static final String W4B = "com.whatsapp.w4b", WA = "com.whatsapp";

    static SharedPreferences sp(Context c) { return c.getSharedPreferences("ventas", Context.MODE_PRIVATE); }

    static boolean enabled(Context c) {
        String f = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return f != null && f.contains(new ComponentName(c, WaListener.class).flattenToString());
    }

    static boolean installed(Context c, String p) {
        try { c.getPackageManager().getPackageInfo(p, 0); return true; } catch (PackageManager.NameNotFoundException e) { return false; }
    }

    /** Qué WhatsApp se lee: elegido en la app (Más → WhatsApp → CRM): "wa" normal, "w4b" Business, "both" los dos.
     *  Sin elegir: Business si está instalado; si no, el normal. */
    static String appSel(Context c) { return sp(c).getString("waApp", "auto"); }
    static boolean accepts(Context c, String pkg) {
        String sel = appSel(c);
        if (sel.equals("wa")) return WA.equals(pkg);
        if (sel.equals("w4b")) return W4B.equals(pkg);
        if (sel.equals("both")) return WA.equals(pkg) || W4B.equals(pkg);
        return (installed(c, W4B) ? W4B : WA).equals(pkg);
    }

    static String cs(CharSequence s) { return s == null ? "" : s.toString(); }

    static String jidPhone(String s) {
        if (s == null) return "";
        int i = s.indexOf("@s.whatsapp.net");
        if (i <= 0) return "";
        String d = s.substring(0, i).replaceAll("[^0-9]", "");
        return d.length() >= 8 ? d : "";
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            Context c = getApplicationContext();
            if (sbn == null || !accepts(c, sbn.getPackageName())) return;
            // WhatsApp duplicado (Dual Messenger / Apps gemelas) vive en otro perfil de Android
            boolean dual = sbn.getUser() != null && !sbn.getUser().equals(android.os.Process.myUserHandle());
            if (dual && !sp(c).getBoolean("waSeenDual", false)) sp(c).edit().putBoolean("waSeenDual", true).apply();
            String prof = sp(c).getString("waProfile", "both");
            if ((prof.equals("main") && dual) || (prof.equals("dual") && !dual)) return;
            if (sp(c).getString("waTok", "").isEmpty()) return; // nadie ha entrado en la app de Ventas
            Notification n = sbn.getNotification();
            if (n == null || n.extras == null || (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) return;
            if (Notification.CATEGORY_CALL.equals(n.category) || Notification.CATEGORY_MISSED_CALL.equals(n.category)) return;
            Bundle e = n.extras;
            if (e.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION, false)) return;
            String sid = n.getShortcutId(), tag = sbn.getTag();
            if ((sid != null && (sid.contains("@g.us") || sid.contains("broadcast"))) || (tag != null && (tag.contains("@g.us") || tag.contains("broadcast")))) return;
            String title = cs(e.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
            if (title.isEmpty()) title = cs(e.getCharSequence(Notification.EXTRA_TITLE));
            title = title.replaceAll("\\s*\\(\\d+\\s+[^)]*\\)\\s*$", "").replaceAll("^\\s*\\u200e?", "").trim();
            String low = title.toLowerCase();
            if (title.isEmpty() || low.equals("whatsapp") || low.equals("whatsapp business") || low.contains("whatsapp web") || low.contains(" @ ")) return;
            String phone = jidPhone(sid);
            if (phone.isEmpty()) phone = jidPhone(tag);
            if (phone.isEmpty() && title.matches("^[0-9+ ()\\-\\u202a\\u202c]{8,}$")) phone = title.replaceAll("[^0-9]", "");
            String conv = sbn.getPackageName() + (dual ? "#2" : "") + (phone.isEmpty() ? "|n:" + low : "|p:" + phone);
            long last = sp(c).getLong("wal_" + conv, 0), maxAt = last;

            JSONArray q = new JSONArray(sp(c).getString("waq", "[]"));
            Parcelable[] arr = e.getParcelableArray(Notification.EXTRA_MESSAGES);
            if (arr != null && arr.length > 0) {
                List<Notification.MessagingStyle.Message> ms = Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr);
                for (Notification.MessagingStyle.Message m : ms) {
                    long at = m.getTimestamp();
                    if (at <= last) continue;
                    boolean me = android.os.Build.VERSION.SDK_INT >= 28 ? m.getSenderPerson() == null : m.getSender() == null;
                    String txt = cs(m.getText()).trim();
                    if (txt.isEmpty()) continue;
                    q.put(new JSONObject().put("phone", phone).put("name", title).put("text", txt).put("at", at).put("dir", me ? "out" : "in"));
                    if (at > maxAt) maxAt = at;
                }
            } else {
                String txt = cs(e.getCharSequence(Notification.EXTRA_TEXT)).trim(), tl = txt.toLowerCase();
                long at = sbn.getPostTime();
                if (txt.isEmpty() || at <= last || tl.matches("^\\d+ (mensajes|new messages|messages|nuevos mensajes).*") || tl.contains("comprobando si hay mensajes") || tl.contains("checking for new messages")) return;
                q.put(new JSONObject().put("phone", phone).put("name", title).put("text", txt).put("at", at).put("dir", "in"));
                maxAt = at;
            }
            if (maxAt == last) return;
            while (q.length() > 300) q.remove(0);
            sp(c).edit().putString("waq", q.toString()).putLong("wal_" + conv, maxAt).apply();
            flush(c);
        } catch (Exception ignored) { }
    }

    static volatile boolean busy = false;

    /** Manda la cola al servidor (en segundo plano). Si no hay internet, queda para la próxima vez. */
    static void flush(Context ctx) {
        final Context c = ctx.getApplicationContext();
        if (busy) return;
        busy = true;
        new Thread(() -> {
            try {
                SharedPreferences p = sp(c);
                String q = p.getString("waq", "[]"), tok = p.getString("waTok", ""), srv = p.getString("waSrv", MainActivity.DEF_SERVER);
                if (tok.isEmpty() || q.equals("[]")) return;
                JSONArray items = new JSONArray(q);
                HttpURLConnection h = (HttpURLConnection) new URL(srv + "/api/o/v/wa").openConnection();
                h.setRequestMethod("POST");
                h.setConnectTimeout(15000);
                h.setReadTimeout(20000);
                h.setDoOutput(true);
                h.setRequestProperty("Content-Type", "application/json");
                h.setRequestProperty("X-O-Token", tok);
                try (OutputStream o = h.getOutputStream()) { o.write(new JSONObject().put("items", items).toString().getBytes(StandardCharsets.UTF_8)); }
                int code = h.getResponseCode();
                h.disconnect();
                if (code == 200) {
                    // quitar solo lo que se mandó (pudo llegar algo nuevo mientras tanto)
                    JSONArray now = new JSONArray(p.getString("waq", "[]")), rest = new JSONArray();
                    for (int i = items.length(); i < now.length(); i++) rest.put(now.get(i));
                    p.edit().putString("waq", rest.toString()).putLong("waOk", System.currentTimeMillis()).apply();
                } else if (code == 401 || code == 403) {
                    p.edit().putString("waq", "[]").apply(); // sin permiso: no acumular
                }
            } catch (Exception ignored) {
            } finally { busy = false; }
        }).start();
    }
}
